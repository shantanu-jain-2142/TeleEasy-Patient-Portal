import json
import boto3
from datetime import datetime, timezone

def lambda_handler(event, context):
    # patient_id = event["patient_id"]
    # requested_plan_id = event["requested_plan_id"]
    print('event',event)
    print('keys',event.keys())
    patient_id = event['body-json']["patient_id"]
    requested_plan_id = event['body-json']["requested_plan_id"]
    
    print("request data - {}, {}".format(patient_id, requested_plan_id))
    
    s3 = boto3.resource('s3')
    content_object = s3.Object('coms-6998-static-data-hosting', 'company_plan_information.json')
    file_content = content_object.get()['Body'].read().decode('utf-8')
    json_content = json.loads(file_content)
    data_list = json_content
    
    appointments_to_allocate = 0
    
    print(data_list)
    
    for r in data_list:
        if int(r["plan_id"]) == int(requested_plan_id):
            appointments_to_allocate = r["number_of_appointments"]
            print("found the requested plan")
            break
        
    c = datetime.now(timezone.utc).strftime("%m-%d-%Y %H:%M:%S")
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('coms-6998-patients')

    response = table.update_item(
        Key = {
                'patient_id': patient_id   
        },
        UpdateExpression = "set #a1=:p1, #a2=:p2, #a3=:p3",
        ExpressionAttributeValues={
            ':p1' : requested_plan_id,
            ':p2' : c,
            ':p3' : appointments_to_allocate
        },
        ExpressionAttributeNames={
            '#a1': 'subs_plan_plan_id',
            '#a2': 'subs_plan_start_datetime',
            '#a3': 'subs_plan_remaining_num_appointments'
        },
        ReturnValues="UPDATED_NEW"
    )
    
    return {
        'statusCode': 200,
        'body': response["Attributes"]
    }