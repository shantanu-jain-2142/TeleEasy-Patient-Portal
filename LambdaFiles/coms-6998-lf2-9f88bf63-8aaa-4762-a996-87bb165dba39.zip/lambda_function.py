import boto3
import botocore.exceptions
import logging

SQS_URL = 'https://sqs.us-east-2.amazonaws.com/780413323879/coms-6998-appointment-queue'
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

# NOTE: if the parameter passed in start_datetime is a datetime object, then use this code:
# request_params['start_datetime'].strftime("%m/%d/%Y, %H:%M:%S")
# else keep it as a string

def lambda_handler(event, context):
    """
    Adding the appointment details to SQS
    """
    
    print(event)
    sqs_client = boto3.client('sqs')
    # request_params = event
    request_params = event["body-json"]
    messageAttributes = {
        'Patient_ID': {
            'DataType': 'String',
            'StringValue': request_params['patient_id']
        },
        'Doctor_ID': {
            'DataType': 'String',
            'StringValue': request_params['doctor_id']
        },
        'Start_Time': {
            'DataType': 'String',
            'StringValue': request_params['start_datetime']
        },
        'Context': {
            'DataType': 'String',
            'StringValue': request_params['patient_context']
        }
    }
    try:
        logger.info('Sending message to SQS...')
        response = sqs_client.send_message(QueueUrl=SQS_URL, MessageBody="Message from LF2", MessageAttributes=messageAttributes)
    except botocore.exceptions.ClientError as error:
        logger.error("Failed to send the appointment details to SQS: {}".format(error.response['Error']['Message']))
        return {'code': 400, 'message': 'Failed to send the appointment details to SQS.'}
    return {'code': 200}