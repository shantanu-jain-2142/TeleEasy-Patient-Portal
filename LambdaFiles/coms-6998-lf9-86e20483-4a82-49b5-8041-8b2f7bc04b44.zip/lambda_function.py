import json
import boto3
from decimal import Decimal
from datetime import datetime
import requests
from requests_aws4auth import AWS4Auth
from elasticsearch import Elasticsearch, RequestsHttpConnection
    

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')

    dynamoClient = boto3.client('dynamodb')
    table = dynamodb.Table('coms-6998-slots')
    event = event["params"]["querystring"]
    query_doctor_id = event["doctor_id"]
    
    response = dynamoClient.query(
    TableName='coms-6998-slots',
    KeyConditionExpression='doctor_id = :doctor_id ',
    ExpressionAttributeValues={
        ':doctor_id': {'S': query_doctor_id}
    })
    
    valid_slot_list=[]
    
    for item in response['Items']:
        if item['valid']['BOOL'] == True:
            valid_slot_list.append(item)
            
    
    return valid_slot_list
