import boto3
import botocore.exceptions
import hmac
import hashlib
import base64
import json
USER_POOL_ID = 'us-east-2_4lMGb9GS4'
CLIENT_ID = '5a1rr1nvbds5iramf8k2q77aio'
CLIENT_SECRET ='13emrbre7v2q0eae37ef77tppfmaiudabk9c0lfms79mol6bd7l'

def get_secret_hash(username):
    msg = username + CLIENT_ID
    dig = hmac.new(str(CLIENT_SECRET).encode('utf-8'), 
        msg = str(msg).encode('utf-8'), digestmod=hashlib.sha256).digest()
    d2 = base64.b64encode(dig).decode()
    return d2

def lambda_handler(event, context):
    for field in ["username", "email", "password", "given_name", "family_name", "gender", "address", "phone_no"]:
        if not event.get(field):
            return {"error": False, "success": True, 'message': f"{field} is not present", "data": None}
    username = event['username']
    email = event["email"]
    password = event['password']
    first_name = event["given_name"]
    last_name = event["family_name"]
    gender = event["gender"]
    address = event["address"]
    number = event["phone_no"]
    
    print("FirstName: {}".format(first_name))
    
    client = boto3.client('cognito-idp')
    try:
        resp = client.sign_up(
            ClientId=CLIENT_ID,
            SecretHash=get_secret_hash(username),
            Username=username,
            Password=password, 
            UserAttributes=[
            {
                'Name': "family_name",
                'Value': last_name
            },
            {
                'Name': "given_name",
                'Value': first_name
            },
            {
                'Name': "address",
                'Value': address
            },
            {
                'Name': "gender",
                'Value': gender
            },
            {
                'Name': "phone_number",
                'Value': number
            },
            {
                'Name': "email",
                'Value': email
            }
            ],
            ValidationData=[
                {
                'Name': "email",
                'Value': email
            },
            {
                'Name': "custom:username",
                'Value': username
            }
        ])
    
    
    except client.exceptions.UsernameExistsException as e:
        return {"error": False, 
               "success": True, 
               "message": "This username already exists", 
               "data": None}
    except client.exceptions.InvalidPasswordException as e:
        
        return {"error": False, 
               "success": True, 
               "message": "Password should have Caps, Special chars, Numbers", 
               "data": None}
    except client.exceptions.UserLambdaValidationException as e:
        return {"error": False, 
               "success": True, 
               "message": "Email already exists", 
               "data": None}
    
    except Exception as e:
        return {"error": False, 
                "success": True, 
                "message": str(e), 
               "data": None}
    
    return {"error": False, 
            "success": True, 
            "message": "Please confirm your signup, \
                        check Email for validation code", 
            "data": None}