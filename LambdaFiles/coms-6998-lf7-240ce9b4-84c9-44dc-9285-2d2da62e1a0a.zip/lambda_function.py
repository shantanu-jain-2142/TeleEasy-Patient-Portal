import boto3
import json
import requests
from requests_aws4auth import AWS4Auth
from boto3.dynamodb.conditions import Key, Attr

def lambda_handler(event, context):
    event = event["params"]["querystring"]
    
    
    print(event)    ## doctor ID
    

    # {
    #     "session_id": "string",
    #     "user_id": "string",
    #     "doctor_id": "string"
    #     "view_slots": 'true'
    #     "view_appointments": 'true'
    # }
    
    query_doctor_id = event["doctor_id"]
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('coms-6998-doctors')
    
    '''
    # Elasticsearch for slots
    region = 'us-east-2'
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    host = '' # For example, search-mydomain-id.us-west-1.es.amazonaws.com
    index = 'slots'
    url = 'https://' + host + '/' + index + '/_search'
    headers = { "Content-Type": "application/json" }
    
    query = {
        "size": 10,        
        "query": {
            "query_string": {
              "default_field": "doctor_id",
              "query": query_doctor_id
            }
        }
    }
    
    try:
        r = requests.get(url, auth=awsauth, headers=headers, data=json.dumps(query)).json()
        search_result_list = r["hits"]["hits"]
    except:
        # dummy result
        search_result_list = [
            {
                "_id": 'cdeville0',
                "_source": {
                    "doctor_id": 'cdeville0',
                    "createdTimestamp": '',
                    "start_datetime": '',
                    "end_datetime": ''
                }
            },
            {
                "_id": 'cdeville0',
                "_source": {
                    "doctor_id": 'cdeville0',
                    "createdTimestamp": '',
                    "start_datetime": '',
                    "end_datetime": ''
                }
            }
        ]
    
    print(search_result_list)
    '''
    result_slots = []
    result_appointments = []
    
    db_response = table.query(
                KeyConditionExpression=Key('doctor_id').eq(query_doctor_id)
        )
    doctor_details = db_response["Items"][0]
        
    if ('view_slots' in event) and (event['view_slots'] == 'true'):
        slotstable = dynamodb.Table('coms-6998-slots')
        db_response = slotstable.query(
                KeyConditionExpression=Key('doctor_id').eq(query_doctor_id)
        )
        result_slots = db_response["Items"]
    
    if ('view_appointments' in event) and (event['view_appointments'] == 'true'):
        apptstable = dynamodb.Table('coms-6998-appointments')
        db_response = apptstable.scan(
                # KeyConditionExpression=Key('doctor_id').eq(query_doctor_id)
                FilterExpression=Attr('doctor_id').eq(query_doctor_id)
        )
        result_appointments = db_response["Items"]
        
    return {
        'doctor': doctor_details,
        'slots': result_slots,
        'appointments': result_appointments
    }
