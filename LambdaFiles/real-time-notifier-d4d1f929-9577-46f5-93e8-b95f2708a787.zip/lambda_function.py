import json
import boto3
from datetime import datetime, timedelta
from pytz import timezone



def fetch_email(user_id):
    dynamodb = boto3.resource('dynamodb')
    dynamo_table = dynamodb.Table('coms-6998-patients')
    
    response = dynamo_table.get_item(Key=user_id)
    return response['Item']['email']


def send_email(ip):
    ses_client = boto3.client('ses')
    
    message =  """
    You have an upcoming appointment. Please login to TeleEasy at the time of your appointment. 
    Please find the details here - 
    """
    
    message = message + """
        Appointment Time: {},
        Doctor ID: {},
        Patient Context: {}
    """.format(ip['start_datetime'], ip['doctor_id'], ip['patient_context'])
    

    patient_email = fetch_email({'patient_id': ip['patient_id']})
    print("patient_email: {}".format(patient_email))

    m={
                'Subject': {
                    'Data': "TeleEasy Appointment Reminder!!!    Appointment ID: {}".format(ip['appointment_id']),
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': message,
                        'Charset': 'UTF-8'
                    },
                    'Html': {
                        'Data': message,
                        'Charset': 'UTF-8'
                    }
                }
            }

    
    mail_response = ses_client.send_email(
        Source="shantanu.jain3597@gmail.com",
        Destination={'ToAddresses': [patient_email]},
        Message=m
    )
    
    print("ses message")
    print(m)
    
    return mail_response
    
    
def lambda_handler(event, context):
    # TODO implement
    
    print("lambda invoked******")
    
    # Code from https://dynobase.dev/dynamodb-python-with-boto3/#:~:text=To%20get%20all%20items%20from,the%20results%20in%20a%20loop.
    dynamodb = boto3.resource('dynamodb', region_name='us-east-2')
    table = dynamodb.Table('coms-6998-appointments')
    
    response = table.scan()
    data = response['Items']
    
    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        data.extend(response['Items'])
    
    for e in data:
        if 'start_datetime' in e:
            d1 = datetime.strptime(e['start_datetime'], '%m/%d/%Y, %H:%M')
            tz = timezone('EST')
            d2 = datetime.now(tz).replace(tzinfo=None) + timedelta(hours=1)
            # d2 = datetime.now(tz)
            
            print("######")
            print(d1)
            print(d2)
            
            # time_diff_min = (d2 - d1).days * 24 * 60
            diff = d2 - d1
            time_diff_min = diff.total_seconds() / 60
            print("time_diff_min_outside_if: ", time_diff_min)
            
            if abs(time_diff_min) < 2:
                print("time_diff_min: {}".format(time_diff_min))
                print("#######")
                
                ip = {
                    'start_datetime': e['start_datetime'],
                    'appointment_id': e['appointment_id'],
                    'patient_context': e['patient_context'],
                    'doctor_id': e['doctor_id'],
                    'patient_id': e['patient_id']
                }
                
                send_email(ip)
            
    return