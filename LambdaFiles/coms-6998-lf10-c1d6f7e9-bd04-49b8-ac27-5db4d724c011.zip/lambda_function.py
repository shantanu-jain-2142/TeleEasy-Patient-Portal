import json
import boto3
from decimal import Decimal
from datetime import datetime
import requests
from requests_aws4auth import AWS4Auth
from elasticsearch import Elasticsearch, RequestsHttpConnection
    

def lambda_handler(event, context):
    dynamodb = boto3.client('dynamodb')

    # table = dynamodb.Table('coms-6998-slots')
    # query_doctor_id = event["doctor_id"]
    print ('E',event)
    event = event["body-json"] 
    print (event)
    # input_slot_list = [
    #     {'doctor_id':'doc_1',
    #      'start_datetime' : '03/29/2021, 11:34',
    #      'end_datetime' : '03/29/2021, 11:34',
    #      'valid' : True
    #     },
    #     {'doctor_id':'doc_2',
    #      'start_datetime' : '03/29/2021, 11:34',
    #      'end_datetime' : '03/29/2021, 11:34',
    #      'valid' : False
    #     }]
    input_slot_list = event['slots']
    for item in input_slot_list:
        item = {
                'doctor_id':{'S':item['doctor_id']},
                'start_datetime':{'S':item['start_datetime']},
                'end_datetime':{'S': item['end_datetime']},
                'valid':{'BOOL': item['valid']}
        }
        response = dynamodb.put_item(
                TableName='coms-6998-slots', 
                Item=item
            )
            

    return response
