import boto3
import os
import json
import uuid
import logging
import requests
from elasticsearch import Elasticsearch, RequestsHttpConnection
from requests_aws4auth import AWS4Auth
from zoomus import ZoomClient
import datetime
import pprint 

SQS_URL = 'https://sqs.us-east-2.amazonaws.com/780413323879/coms-6998-appointment-queue'
APPOINTMENT_TABLE = 'coms-6998-appointments'
SLOTS_TABLE = 'coms-6998-slots'
PATIENT_TABLE = 'coms-6998-patients'
DOCTOR_TABLE = 'coms-6998-doctors'
ES_ENDPOINT = 'search-coms-6998-appointments-4poxkfvqpdvho5jvr2q7oyo6km.us-east-2.es.amazonaws.com'

# configuration for zoom email
SENDER_EMAIL = "shantanu.jain3597@gmail.com"
PARAM_API_KEY = "MwBB32UyRX6nm544ivMpNw"
PARAM_API_SEC = "WduBA50Z2gI22dnsYFBh1fBEJPG9gbA3DRkH"
PARAM_ZOOM_EMAIL = "teleeasyinc@gmail.com"

# setting up the logger configuration
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

def lambda_handler(event, context):
    """
    Add the appointment in DynamoDB, ES and send a mail to the user.
    """
    # TODO:
    # check whether to keep valid as boolean or string -- done
    # delete the SQS event.
    # delete the patient email marked as shantanujainrko.
    # create a CW Trigger to trigger this function.
    # Formatting the mail.
    
    appointment_details = poll_sqs()
    if appointment_details == None:
        logger.info("Nothing to poll")
        return {'code': 200 }
    check_slot = make_slot_invalid(appointment_details)
    if(check_slot == False): 
        return {'code': 400, 'message': 'The slot is inactive and is not available. Please select another slot.'}
    zoom_information = create_zoom_meeting(appointment_details)
    appointment_details['appointment_id'] = add_to_dynamodb(appointment_details, zoom_information)
    add_to_ES(appointment_details['patient_id'], appointment_details['appointment_id'])
    send_email(appointment_details, zoom_information)
    return { 'code': 200 }


def poll_sqs():
    """
    Polls sqs for appointment information
    """
    logger.info("Receiving appointments from SQS...")
    sqs_client = boto3.client('sqs')
    response = sqs_client.receive_message(
        QueueUrl=SQS_URL,
        AttributeNames = ['All'],
        MessageAttributeNames = ['All'],
        MaxNumberOfMessages=1,
        WaitTimeSeconds=20
    )
    if 'Messages' not in response:
        logger.info('No messages available to poll. Retrying after x seconds...')
        return None

    # if message is received, delete the same
    logger.info('Deleting the SQS message...')
    receiptHandle = response['Messages'][0]['ReceiptHandle']
    sqs_client.delete_message(QueueUrl=SQS_URL, ReceiptHandle=receiptHandle)

    # fetching the attributes
    logger.info('Fetching the data from SQS...')
    appointment_information =  {}
    appointment_information['patient_id'] = response['Messages'][0]['MessageAttributes']['Patient_ID']['StringValue']
    appointment_information['doctor_id'] = response['Messages'][0]['MessageAttributes']['Doctor_ID']['StringValue']
    appointment_information['start_datetime'] = response['Messages'][0]['MessageAttributes']['Start_Time']['StringValue']
    # appointment_information['end_time'] = response['Messages'][0]['MessageAttributes']['End_Time']['StringValue']
    appointment_information['patient_context'] = response['Messages'][0]['MessageAttributes']['Context']['StringValue']
    logger.info("Appointment Details fetched from SQS: {}".format(appointment_information))

    return appointment_information

def add_to_dynamodb(appointment_details, meeting_details):
    """
    Add the appointments to dynamo db
    """
    dynamodb = boto3.resource('dynamodb')
    appointments_table = dynamodb.Table(APPOINTMENT_TABLE)

    # generating the appointment_id as a random variable
    appointment_id = str(uuid.uuid4().hex)
    logger.info("Appointment ID: {}".format(appointment_id))

    # adding the appointment in the dynamo db table
    response = appointments_table.put_item(
        Item={
            'appointment_id': appointment_id,
            'patient_id': appointment_details['patient_id'],
            'doctor_id': appointment_details['doctor_id'],
            'start_datetime': appointment_details['start_datetime'],
            'patient_context': appointment_details['patient_context'],
            'zoom_meeting_id': meeting_details['id'],
            'zoom_meeting_password': meeting_details['encrypted_password']
        }
    )
    return appointment_id

def add_to_ES(patient_id, appointment_id):
    """
    Indexes user_id and stores all the appointment_id with that user
    """
    logger.info('Adding the user_id to appointment_id...')
    service = 'es'
    credentials = boto3.Session().get_credentials()
    region = os.environ['AWS_DEFAULT_REGION']
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

    es = Elasticsearch(
    hosts = [{'host': ES_ENDPOINT, 'port': 443}],
    http_auth = awsauth,
    use_ssl = True,
    verify_certs = True,
    connection_class = RequestsHttpConnection
    )

    headers = {'Content-Type': 'application/json'}
    AUTH_USER = 'coms-6998'
    AUTH_PW = 'Coms-6998'
    bulk_file = ''
    bulk_file += '{{ "index" : {{ "_index" : "{}", "_type" : "_doc"}} }}\n'.format(patient_id)
    bulk_file += '{{ "appointment_id": "{}" }}'.format(str(appointment_id)) + '\n'
    es_url = "https://" + ES_ENDPOINT + "/_bulk"
    logger.info('ES URL: {}'.format(es_url))

    index_request = requests.put(es_url, headers=headers, data=bulk_file, auth=(AUTH_USER, AUTH_PW)).text
    logger.info("The request object received: {}".format(index_request))

def create_zoom_meeting(appointment_information):
    
    logger.info('Generating the zoom link to be sent to the patient...')
    # creating a zoom client
    client = ZoomClient(PARAM_API_KEY, PARAM_API_SEC)
    
    # fetch patient name and doctor name from their respective dynamodb tables
    attributes_to_fetch = ['first_name', 'last_name']
    patient_attributes = fetch_user_details(PATIENT_TABLE, 
                                attributes_to_fetch,
                                {'patient_id': appointment_information['patient_id']}
                                )
    patient_name = patient_attributes[0]+' '+patient_attributes[1]
    doctor_attributes = fetch_user_details(DOCTOR_TABLE,
                                attributes_to_fetch,
                                {'doctor_id': appointment_information['doctor_id']}
                                )
    doctor_name = doctor_attributes[0]+' '+doctor_attributes[1]
    logger.info('PatientName: {}; DoctorName: {}'.format(patient_name, doctor_name))

    # assigning the parameters required for creating a zoom meeting
    meeting_schedule_time = appointment_information['start_datetime'] # string object
    meeting_schedule_time_datetime = datetime.datetime.strptime(meeting_schedule_time, "%m/%d/%Y, %H:%M")
    
    meeting_schedule_topic = """Consultation - Doctor:{}, Patient:{}""".format(
                                    doctor_name,
                                    patient_name
                                )
    meeting_schedule_agenda = """Doctor:{}, Patient:{}""".format(
                                    doctor_name,
                                    patient_name
                                )
    meeting_schedule_duration = 15
    zoom_meeting = json.loads(client.meeting.create(topic=meeting_schedule_topic,
                                        type=2,
                                        start_time=meeting_schedule_time_datetime,
                                        duration=meeting_schedule_duration,
                                        user_id=PARAM_ZOOM_EMAIL,
                                        agenda=meeting_schedule_agenda,
                                        host_id=PARAM_ZOOM_EMAIL
                                        ).content)

    logger.info('Zoom meeting information: {}'.format(zoom_meeting)) 
    
    # filter zoom_meeting to pass only relevant information
    zoom_meeting_details = {}
    zoom_meeting_details['id'] = zoom_meeting['id']
    # zoom_meeting_details['host_email'] = zoom_meeting['host_email']
    zoom_meeting_details['topic'] = zoom_meeting['topic']
    zoom_meeting_details['start_time'] = zoom_meeting['start_time']
    zoom_meeting_details['duration'] = zoom_meeting['duration']
    zoom_meeting_details['agenda'] = zoom_meeting['agenda']
    # zoom_meeting_details['start_url'] = zoom_meeting['start_url']
    # zoom_meeting_details['join_url'] = zoom_meeting['join_url']
    # zoom_meeting_details['password'] = zoom_meeting['password']
    zoom_meeting_details['encrypted_password'] = zoom_meeting['encrypted_password']
    
    return zoom_meeting_details

def send_email(appointment_details, meeting_details):
    """
    Send email to the user and possibly the zoom link
    """
    logger.info('Sending email to the user...')
    ses_client = boto3.client('ses')
    
    zoom_meeting_details = {}
    zoom_meeting_details['topic'] = meeting_details['topic']
    zoom_meeting_details['start_time'] = meeting_details['start_time']
    zoom_meeting_details['duration'] = meeting_details['duration']
    zoom_meeting_details['agenda'] = meeting_details['agenda']
    
    message =  """
    TeleEasy has created an appointment for you. Please find the details of the meeting below.
    Meeting Information: \n
    {}
    """.format(zoom_meeting_details)
    
    # fetch user email to send mail to
    patient_email = fetch_user_details(PATIENT_TABLE,
                                    ['email'],
                                    {'patient_id': appointment_details['patient_id']})[0]
    # patient_email = 'shantanujainrko@gmail.com'

    # Send a mail to the user regarding appointment confirmation
    mail_response = ses_client.send_email(
        Source=SENDER_EMAIL,
        Destination={'ToAddresses': [patient_email]},
        Message={
            'Subject': {
                'Data': "Appointment Confirmaton: {}".format(appointment_details['appointment_id']),
                'Charset': 'UTF-8'
            },
            'Body': {
                'Text': {
                    'Data': message,
                    'Charset': 'UTF-8'
                },
                'Html': {
                    'Data': message,
                    'Charset': 'UTF-8'
                }
            }
        }
    )
    return mail_response

def fetch_user_details(table_name, attributes, user_id):
    """
    Returns an array of attribute values from a set of attributes from the table
    """
    
    logger.info('Fetching details from table: {}'.format(table_name))
    attribute_values = []
    
    dynamodb = boto3.resource('dynamodb')
    dynamo_table = dynamodb.Table(table_name)
    
    response = dynamo_table.get_item(Key=user_id)
    for attribute in attributes:
        attribute_values.append(response['Item'][attribute])
    
    return attribute_values

def make_slot_invalid(appointment_details):
    """Makes that corresponding slot invalid after the appointment is booked
    """
    
    # create a dynamodb object
    dynamodb = boto3.resource('dynamodb')
    slots_table = dynamodb.Table(SLOTS_TABLE)
    
    # check if the slot is already filled or not
    check_slot = slots_table.get_item(
            Key={
                'doctor_id': appointment_details['doctor_id'],
                'start_datetime': appointment_details['start_datetime']
            })
    logger.info("Slots Response: {}".format(check_slot))
    
    if 'Item' not in check_slot:
        logger.info('No slots available for the said doctor.')
        return False
    
    if check_slot['Item']['valid'] == False:
        logger.info('The slot is not available and hence cannot be booked.')
        return False
        # return {'code': 400, 'message': 'The slot is inactive and is not available. Please select another slot.'}
    
    logger.info("Updating the slot of the doctor...")
    # update the item based on the doctor id and start time
    response = slots_table.update_item(
            Key={
                'doctor_id': appointment_details['doctor_id'],
                'start_datetime': appointment_details['start_datetime']
            },
            UpdateExpression='SET valid = :false',
            ExpressionAttributeValues={":false": False}
        )
    return True