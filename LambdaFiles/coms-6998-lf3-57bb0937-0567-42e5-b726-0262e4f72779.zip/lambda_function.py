import json
import boto3
import botocore

def lambda_handler(event, context):
    print("event: ", event)
    print("context: ", context)
    
    # patient_id = event["patient_id"]
    patient_id = event["params"]["querystring"]["patient_id"]
    
    profile_pic_url = None
    
    # Code based on https://stackoverflow.com/questions/33842944/check-if-a-key-exists-in-a-bucket-in-s3-using-boto3#:~:text=boto3%20s3%20%3D%20boto3.-,resource('s3')%20bucket%20%3D%20s3.,doesn't%20exist!%22)
    s3 = boto3.resource('s3')
    try:
        s3.Object('coms-6998-profile-pics', "patients/" + str(patient_id) + '.png').load()
    except botocore.exceptions.ClientError as e:
        if e.response['Error']['Code'] == "404":
            print("Profile pic not found")
        else:
            print("Profile pic fetch failed")
    else:
        print("Profile pic found")
        profile_pic_url = "https://coms-6998-profile-pics.s3.us-east-2.amazonaws.com/patients/" + str(patient_id) + ".png"
        
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('coms-6998-patients')
    
    response = table.get_item(Key={'patient_id': patient_id})
    
    
    if "Item" in response:
        print("patient_data")
        print(response["Item"])
        r = response["Item"]
    else:
        print("invalid key")
        return

    ret_subs_plan_plan_id = None
    if "subs_plan_plan_id" in r:
        ret_subs_plan_plan_id = r["subs_plan_plan_id"]
        
    ret_subs_plan_remaining_num_appointments = None
    if "subs_plan_remaining_num_appointments" in r:
        ret_subs_plan_remaining_num_appointments = r["subs_plan_remaining_num_appointments"]
        
    ret_subs_plan_start_datetime = None
    if "subs_plan_start_datetime" in r:
        ret_subs_plan_start_datetime = r["subs_plan_start_datetime"]
        
    ret_gender = None
    if "gender" in r:
        ret_gender = r["gender"]
    
    ret_dob = None
    if "dob" in r:
        ret_dob = r["dob"]

    ret_obj = {
        "patient_id": r["patient_id"],
        "last_name": r["last_name"],
        "first_name": r["first_name"],
        "email": r["email"],
        "address": r["address"],
        "mobile_no": r["mobile_no"],
        "gender": ret_gender,
        "dob": ret_dob,
        "curr_plan": {
            "subs_plan_plan_id": ret_subs_plan_plan_id,
            "subs_plan_remaining_num_appointments": ret_subs_plan_remaining_num_appointments,
            "sub_plan_start_datetime": ret_subs_plan_start_datetime
            
        },
        "profile_pic_url": profile_pic_url
    }    

    return {
        'statusCode': 200,
        'body': ret_obj
    }
