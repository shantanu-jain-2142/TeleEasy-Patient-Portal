import os
import json
import logging
import boto3
from elasticsearch import Elasticsearch, RequestsHttpConnection
import requests
from requests_aws4auth import AWS4Auth

APPOINTMENT_TABLE = 'coms-6998-appointments'
ES_ENDPOINT = 'search-coms-6998-appointments-4poxkfvqpdvho5jvr2q7oyo6km.us-east-2.es.amazonaws.com'

# setting up the logger
logging.basicConfig(format='%(asctime)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S')
logger = logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

def lambda_handler(event, context):
    """
    Lambda handler for fetching all the appointments from the table
    """

    request_params = event["params"]["querystring"]
    
    # getting the params passed to the endpoint
    # request_params = event['request_params']

    # fetch the appointment id from elasticsearch
    appointment_id_list = fetch_appointment_id(request_params['patient_id'])
    if len(appointment_id_list) == 0:
        return {'code': 400, 'results': []}

    # fetch all the appointment details from dynamo db
    dynamodb = boto3.resource('dynamodb')
    appointments_table = dynamodb.Table(APPOINTMENT_TABLE)

    logger.info("Adding the appointments from ES to a list...")
    appointments = []
    for appointment in appointment_id_list:
        logger.info("Appointment_ID: {}".format(str(appointment)))
        response = appointments_table.get_item(Key={'appointment_id': str(appointment)})
        logger.info('response: {}'.format(response))
        if 'Item' in response:
            appointments.append(response['Item'])
    
    return {
        'code': 200,
        'results': appointments
    }

def fetch_appointment_id(patient_id):

    logger.info("Fetching the appointment details from elasticsearch...")
    service = 'es'
    credentials = boto3.Session().get_credentials()
    region = os.environ['AWS_DEFAULT_REGION']
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)

    es = Elasticsearch(
    hosts = [{'host': ES_ENDPOINT, 'port': 443}],
    http_auth = awsauth,
    use_ssl = True,
    verify_certs = True,
    connection_class = RequestsHttpConnection
    )

    AUTH_USER = 'coms-6998'
    AUTH_PW = 'Coms-6998'
    
    query = patient_id
    es_url = "https://" + ES_ENDPOINT + "/_search?index="
    search_results = json.loads(requests.get(es_url+query, auth=(AUTH_USER, AUTH_PW)).text)
    logger.info("Search Results: {}".format(search_results))

    if 'hits' not in search_results:
        logger.info("No appointments for the current patient.")
        return []
    
    appointment_results = search_results['hits']['hits']
    appointment_id_list = []
    for result in appointment_results:
        logger.info("appointment_id: {}".format(result['_source']['appointment_id']))
        appointment_id_list.append(result['_source']['appointment_id'])
    # logger.info("appointment_list: {}".appointment_id_list)
    return appointment_id_list
                  
