import json
def lambda_handler(event, context):
    # TODO implement
    return {
        'error': False,
        "success": True, 
        "message": "Call is successful"
    }