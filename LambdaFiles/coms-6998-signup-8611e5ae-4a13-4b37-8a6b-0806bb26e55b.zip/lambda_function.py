import boto3
import botocore.exceptions
import hmac
import hashlib
import base64
import json
USER_POOL_ID = 'us-east-2_b1P4tVf3u'
CLIENT_ID = '3fuqo712j0lh7vd3rtqs0t5b1h'
CLIENT_SECRET ='103k2qdogu7s35ktfuen9t8mh30o161fmd5f25e9f5vv8qvu3mb3'

def get_secret_hash(username):
    msg = username + CLIENT_ID
    dig = hmac.new(str(CLIENT_SECRET).encode('utf-8'), 
        msg = str(msg).encode('utf-8'), digestmod=hashlib.sha256).digest()
    d2 = base64.b64encode(dig).decode()
    return d2

def lambda_handler(event, context):
    for field in ["username", "email", "password", "given_name", "family_name", "gender", "birth_date", "address", "phone_no"]:
        if not event.get(field):
            return {"error": False, "success": True, 'message': f"{field} is not present", "data": None}
    username = event['username']
    email = event["email"]
    password = event['password']
    first_name = event["given_name"]
    last_name = event["family_name"]
    gender = event["gender"]
    birth_date = event["birth_date"]
    address = event["address"]
    number = event["phone_no"]
    
    print("FirstName: {}".format(first_name))
    
    client = boto3.client('cognito-idp')
    try:
        resp = client.sign_up(
            ClientId=CLIENT_ID,
            SecretHash=get_secret_hash(username),
            Username=username,
            Password=password, 
            UserAttributes=[
            {
                'Name': "family_name",
                'Value': last_name
            },
            {
                'Name': "given_name",
                'Value': first_name
            },
            {
                'Name': "address",
                'Value': address
            },
            {
                'Name': "gender",
                'Value': gender
            },
            {
                'Name': "phone_number",
                'Value': number
            },
            {
                'Name': "birthdate",
                'Value': birth_date
            },
            {
                'Name': "email",
                'Value': email
            }
            ],
            ValidationData=[
                {
                'Name': "email",
                'Value': email
            },
            {
                'Name': "custom:username",
                'Value': username
            }
        ])
    
    
    except client.exceptions.UsernameExistsException as e:
        return {"error": True, 
               "success": False, 
               "message": "This username already exists", 
               "data": None}
    except client.exceptions.InvalidPasswordException as e:
        
        return {"error": True, 
               "success": False, 
               "message": "Password should have Caps, Special chars, Numbers", 
               "data": None}
    except client.exceptions.UserLambdaValidationException as e:
        return {"error": True, 
               "success": False, 
               "message": "Email already exists", 
               "data": None}
    
    except Exception as e:
        return {"error": True, 
                "success": False, 
                "message": str(e), 
               "data": None}
    
    return {"error": False, 
            "success": True, 
            "message": "Please confirm your signup, \
                        check Email for validation code", 
            "data": None}