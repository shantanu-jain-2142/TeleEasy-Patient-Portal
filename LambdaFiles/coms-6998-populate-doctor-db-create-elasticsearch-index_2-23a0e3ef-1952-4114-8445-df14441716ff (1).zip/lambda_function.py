import json
import boto3
from decimal import Decimal
from datetime import datetime
import requests
from requests_aws4auth import AWS4Auth
from elasticsearch import Elasticsearch, RequestsHttpConnection

def create_elastic_search_index(obj):
    es_json = {
        "doctor_id": obj['doctor_id'],
        "doctor_name": obj['first_name']+' '+obj['last_name'],
        "createdTimestamp": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "region": obj['address'],
        "speciality": obj['speciality'],
        "cost": obj['units_per_appointment']
    }
    
    print(es_json)
    
    region = 'us-east-2'
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    
    host = "search-coms-6998-doctors-hohkbwdwqm4bciu6h5d3hjamaq.us-east-2.es.amazonaws.com"           # example - "search-hw2-photos-elastic-search-ehac5wtt5wwksboszvgj5gbynq.us-east-1.es.amazonaws.com"
    
    es = Elasticsearch(
        hosts = [{'host': host, 'port': 443}],
        http_auth = awsauth,
        use_ssl = True,
        verify_certs = True,
        connection_class = RequestsHttpConnection
    )
    

    es.index(index="doctors", id=es_json["doctor_id"], body=es_json)
    
    

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('coms-6998-doctors')
    
    s3 = boto3.resource('s3')

    content_object = s3.Object('coms-6998-random-data-bucket', 'doctor_data_test.json')
    file_content = content_object.get()['Body'].read().decode('utf-8')
    
    json_content = json.loads(file_content)
    db_data_list = json.loads(file_content, parse_float=Decimal)
    print (db_data_list)
    # for r in db_data_list:
    #     response = table.put_item(Item=r)
    for r,obj in zip(db_data_list, json_content):
        print(r)
        try:
            response = table.put_item(Item=r)
            try:
                create_elastic_search_index(obj)
            except:
                print('\t- Failed ES index Creation')
        except:
            print('\t- Failed DB entry')
    
    return 
