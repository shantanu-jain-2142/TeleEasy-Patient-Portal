import json
import boto3
import botocore.exceptions
import hmac
import hashlib
import base64
import uuid

USER_POOL_ID = 'us-east-2_b1P4tVf3u'
CLIENT_ID = '3fuqo712j0lh7vd3rtqs0t5b1h'
CLIENT_SECRET ='103k2qdogu7s35ktfuen9t8mh30o161fmd5f25e9f5vv8qvu3mb3'
USER_TABLE = 'coms-6998-patients'

def get_secret_hash(username):
    msg = username + CLIENT_ID
    dig = hmac.new(str(CLIENT_SECRET).encode('utf-8'), 
        msg = str(msg).encode('utf-8'), digestmod=hashlib.sha256).digest()
    d2 = base64.b64encode(dig).decode()
    return d2

def lambda_handler(event, context):
    client = boto3.client('cognito-idp')
    try:
        username = event['username']
        password = event['password']
        code = event['code']
        response = client.confirm_sign_up(
            ClientId=CLIENT_ID,
            SecretHash=get_secret_hash(username),
            Username=username,
            ConfirmationCode=code,
            ForceAliasCreation=False,
        )
        
        # get the user details from cognito and add it to dynamodb
        user_details_response = client.admin_get_user(
            UserPoolId=USER_POOL_ID,
            Username=event["username"]
        )
        
        user_attributes = user_details_response['UserAttributes']
        print(user_attributes)
        dynamodb = boto3.resource('dynamodb')
        user_table = dynamodb.Table(USER_TABLE)
        
        dynamodb_response = user_table.put_item(
            Item={
                'patient_id': username,
                'address': user_attributes[1]['Value'],
                'first_name': user_attributes[7]['Value'],
                'last_name': user_attributes[8]['Value'],
                'mobile_no': user_attributes[6]['Value'],
                'gender': user_attributes[4]['Value'],
                'dob': user_attributes[2]['Value'],
                'email': user_attributes[-1]['Value']
            }
        )
        
    except client.exceptions.UserNotFoundException:
        #return {"error": True, "success": False, "message": "Username doesnt exists"}
        return event
    except client.exceptions.CodeMismatchException:
        return {"error": True, "success": False, "message": "Invalid Verification code"}
        
    except client.exceptions.NotAuthorizedException:
        return {"error": True, "success": False, "message": "User is already confirmed"}
    
    except Exception as e:
        return {"error": True, "success": False, "message": f"Unknown error {e.__str__()} "}
      
    return event
