import boto3
import json
import requests
from requests_aws4auth import AWS4Auth
from boto3.dynamodb.conditions import Key

def lambda_handler(event, context):
    event = event["params"]["querystring"]
    print(event)    ## filter terms
    # {
    #     "session_id": "string",
    #     "user_id": "string",
    #     "doctor_name": "string",
    #     "region": "string",
    #     "speciality": "string",
    #     "cost_low": int,
    #     "cost_high": int
    # }
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('coms-6998-doctors')
    
    # Elasticsearch
    region = 'us-east-2'
    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, region, service, session_token=credentials.token)
    host = 'search-coms-6998-doctors-hohkbwdwqm4bciu6h5d3hjamaq.us-east-2.es.amazonaws.com' # For example, search-mydomain-id.us-west-1.es.amazonaws.com
    index = 'doctors'
    url = 'https://' + host + '/' + index + '/_search'
    headers = { "Content-Type": "application/json" }
    
    es_fields = ["doctor_id", "doctor_name", "createdTimestamp", "region", "speciality", "cost"]
    
    es_query_string = []
    # query format: "(field:value) AND (field:value) ..."
    for k,v in event.items():
        if (k in es_fields) and (v!=''):
            es_query_string.append("("+k+":"+str(v)+")")
    cost_low = str(event.get('cost_low', '*'))
    cost_high = str(event.get('cost_high', '*'))
    es_query_string.append("(cost:["+cost_low+" TO "+cost_high+"])")
    es_query_string = ' AND '.join(es_query_string)
    print(es_query_string)
    
    query = {
        "size": 25,        
        "query": {
            "query_string": {
                "query": es_query_string
            }
        }
    }
    
    try:
        r = requests.get(url, auth=awsauth, headers=headers, data=json.dumps(query)).json()
        search_result_list = r["hits"]["hits"]
    except:
        # dummy result
        search_result_list = [
            {
                "_id": 'doc_1',
                "_source": {
                    "doctor_id": 'doc_1',
                    "doctor_name": 'Hobart Nitto',
                    "createdTimestamp": '',
                    "region": '279 Kennedy Point',
                    "speciality": [
                        'Pediatrics',
                        'Nuclear medicine'
                    ],
                    "cost": 0.81
                }
            }
        ]
    
    print(search_result_list)
    
    result_doctors = []
    for doctor in search_result_list:
        doctor_id = doctor["_id"]
        db_response = table.query(
                KeyConditionExpression=Key('doctor_id').eq(doctor_id)
        )
        doctor_details = db_response["Items"][0]
        result_doctors.append(doctor_details) 
    
    print('\nDOC SEARCH RESULT:')
    print(result_doctors)
    
    return result_doctors
