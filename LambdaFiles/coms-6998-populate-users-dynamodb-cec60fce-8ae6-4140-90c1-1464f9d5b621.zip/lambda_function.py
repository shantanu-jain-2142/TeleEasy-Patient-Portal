import json
import boto3

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('coms-6998-patients')
    
    s3 = boto3.resource('s3')

    content_object = s3.Object('coms-6998-random-data-bucket', 'users_data.json')
    file_content = content_object.get()['Body'].read().decode('utf-8')
    json_content = json.loads(file_content)

    data_list = json_content

    for r in data_list:
        print(r)
        response = table.put_item(Item=r)
    
    
    



    return 
