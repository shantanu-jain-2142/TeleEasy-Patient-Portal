import json
import boto3
import pytz
from datetime import datetime, timezone

def lambda_handler(event, context):
    patient_id = event["params"]["querystring"]["patient_id"]

    lambda_response = None

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('coms-6998-patients')
    response = table.get_item(Key={'patient_id': patient_id})

    if "Item" in response:
        
        s3 = boto3.resource('s3')
        content_object = s3.Object('coms-6998-static-data-hosting', 'company_plan_information.json')
        file_content = content_object.get()['Body'].read().decode('utf-8')
        json_content = json.loads(file_content)
        data_list = json_content
        
        
        lambda_response = None
        
        print("data_list", data_list)

        if "subs_plan_plan_id" in response["Item"] and "subs_plan_start_datetime" in response["Item"]:
            subs_plan_plan_id = response["Item"]["subs_plan_plan_id"]
            subs_plan_start_datetime = response["Item"]["subs_plan_start_datetime"]
            subs_plan_remaining_num_appointments = response["Item"]["subs_plan_remaining_num_appointments"]
            
            r = None
            for iter_r in data_list:
                if int(iter_r["plan_id"]) == int(subs_plan_plan_id):
                    r = iter_r
                    break
                
            d = datetime.strptime(subs_plan_start_datetime, "%m-%d-%Y %H:%M:%S").replace(tzinfo=pytz.UTC)
            difference = datetime.now(timezone.utc) - d

            if difference.total_seconds() > int(r["plan_duration"]) * 24 * 60 * 60 or subs_plan_remaining_num_appointments == 0:
                lambda_response = {
                    "curr_plan": {
                        "subs_plan_plan_id": None,
                        "subs_plan_remaining_num_appointments": None,
                        "subs_plan_start_datetime": None
                    },
                    "all_plans": data_list
                }
            else:
                lambda_response = {
                    "curr_plan": {
                        "subs_plan_plan_id": response["Item"]["subs_plan_plan_id"],
                        "subs_plan_remaining_num_appointments": response["Item"]["subs_plan_remaining_num_appointments"],
                        "subs_plan_start_datetime": response["Item"]["subs_plan_start_datetime"]
                    },
                    "all_plans": data_list
                }

        else:
            lambda_response = {
                "curr_plan": {
                    "subs_plan_plan_id": None,
                    "subs_plan_remaining_num_appointments": None,
                    "subs_plan_start_datetime": None
                },
                "all_plans": data_list
            }
    
    print(lambda_response)

    return {
        'statusCode': 200,
        'body': lambda_response
    }